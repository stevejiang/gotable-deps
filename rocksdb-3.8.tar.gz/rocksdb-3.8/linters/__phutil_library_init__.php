<?php

phutil_register_library('linters', __FILE__);
